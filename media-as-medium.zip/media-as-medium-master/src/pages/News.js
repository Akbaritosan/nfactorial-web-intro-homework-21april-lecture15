import { Flex, Text } from "@chakra-ui/react";
import { NewsItem } from "../components/NewsItem";
import { news } from "./data";

function News() {
  return (
    <Flex flexDir="column" gap="45px" w="100%">
      <Text
        fontFamily="heading"
        fontSize="5xl"
        fontWeight="medium"
        pt="60px"
        pb="50px"
      >
        Hello, world!
      </Text>
      {news.map((item) => (
        <NewsItem key={item.id} {...item} />
      ))}
    </Flex>
  );
}

export default News;
