import { useParams } from "react-router-dom";
import { news as newsData } from "./data";
import {
  Avatar,
  Box,
  Center,
  Text,
  Flex,
  Circle,
  Link,
  Image,
} from "@chakra-ui/react";
import LeaveIcon from "../assets/icons/LeaveIcon.png";
import HeartIcon from "../assets/icons/HeartIcon.png";
import CommentIcon from "../assets/icons/CommentIcon.png";
import BookmarkIcon from "../assets/icons/BookmarkIcon.png";

function NewsDetailed() {
  const id = useParams().id;
  const news = newsData[id];
  const {
    title,
    authorName,
    avatar,
    body,
    date,
    description,
    duration,
    problem,
    subtitle,
    forWho,
    tag,
    image,
    links,
    type,
  } = news;

  return (
    <Box w="100%" pt="80px">
      <Link href="/">
        <Image src={LeaveIcon} />
      </Link>
      <Flex w="100%" justifyContent="space-between" pt="160px">
        <Flex alignItems="center" gap="16px">
          <Avatar w="64px" h="64px" src={avatar} objectFit="cover" />
          <Box>
            <Text>{authorName}</Text>
            <Flex gap="4px" alignItems="center">
              <Text
                fontWeight="medium"
                textStyle="sm"
                color="black"
                opacity="0.5"
              >
                {date}
              </Text>
              <Circle size="3px" bgColor="black" mx="8px" opacity="0.5" />
              <Text
                fontWeight="medium"
                textStyle="sm"
                color="black"
                opacity="0.5"
              >
                {duration}
              </Text>
              <Circle size="3px" bgColor="black" mx="8px" opacity="0.5" />
              <Text
                fontWeight="medium"
                textStyle="sm"
                color="black"
                opacity="0.5"
              >
                {forWho}
              </Text>
            </Flex>
          </Box>
        </Flex>
        <Flex gap="10px">
          {links.map((link, index) => (
            <Link key={index} to={link.link}>
              <Image src={link.icon} w="24px" h="24px" />
            </Link>
          ))}
        </Flex>
      </Flex>
      <Text fontSize="34px" fontWeight="bold" mt="70px">
        {title}
      </Text>
      <Text fontSize="xl" lineHeight="xl" fontWeight="normal" mt="24px">
        {problem}
      </Text>
      <Image src={image} w="1120px" h="480px" objectFit="cover" mt="70px" />
      <Text fontSize="xl" lineHeight="xl" fontWeight="bold" mt="70px">
        {subtitle}
      </Text>
      <Text
        fontSize="xl"
        lineHeight="xl"
        fontWeight="normal"
        mt="24px"
        whiteSpace="pre-wrap"
      >
        {body}
      </Text>
      <Center justifyContent="space-between" py="70px">
        <Flex gap="17px" alignItems="center">
          <Flex alignItems="center" gap="7px">
            <Image src={HeartIcon} w="24px" h="24px" />
            <Text fontStyle="sm" opacity="0.5" fontWeight="medium">
              180
            </Text>
          </Flex>
          <Flex alignItems="center" gap="7px">
            <Image src={CommentIcon} w="24px" h="24px" />
            <Text fontStyle="sm" opacity="0.5" fontWeight="medium">
              12
            </Text>
          </Flex>
        </Flex>
        <Image src={BookmarkIcon} w="24px" h="24px" />
      </Center>
    </Box>
  );
}

export default NewsDetailed;
