import { createBrowserRouter, Router, useRoutes } from "react-router-dom";
import { lazy } from "react";
import { AppTemplate } from "../templates/AppTemplate";

const NewsPage = lazy(() => import("../pages/News"));
const NewsDetailedPage = lazy(() => import("../pages/NewsDetailed"));

export const routes = createBrowserRouter([
  {
    path: "/",
    element: <AppTemplate />,
    children: [
      {
        path: "/",
        element: <NewsPage />,
      },
      {
        path: "/news/:id",
        element: <NewsDetailedPage />,
      },
    ],
  },
]);
