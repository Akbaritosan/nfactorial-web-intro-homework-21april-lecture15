import { Box } from "@chakra-ui/react";
import { Outlet } from "react-router-dom";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";

export function AppTemplate() {
  return (
    <Box w="100%" minH="100vh" bgColor="#F1F1F1" px="160px">
      <Header />
      <Outlet />
      <Footer />
    </Box>
  );
}
