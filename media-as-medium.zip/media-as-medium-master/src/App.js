import "./App.css";
import { ChakraProvider } from "@chakra-ui/react";
import { theme } from "./theme";
import { routes } from "./routes";
import { RouterProvider } from "react-router-dom";
import { Suspense } from "react";

function App() {
  return (
    <ChakraProvider theme={theme}>
      <Suspense fallback={<div>...loading</div>}>
        <RouterProvider router={routes} />
      </Suspense>
    </ChakraProvider>
  );
}

export default App;
