import { Flex, Text } from "@chakra-ui/react";

export function Header() {
  return (
    <Flex py="24px">
      <Text fontWeight="medium" textStyle="lg" fontFamily="heading">
        Medium Alike
      </Text>
    </Flex>
  );
}
