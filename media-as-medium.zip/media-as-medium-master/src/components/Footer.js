import { Box, Flex, Text } from "@chakra-ui/react";

export function Footer() {
  return (
    <Flex
      flexDir="column"
      alignItems="flex-end"
      justifyContent="flex-end"
      minH="80vh"
    >
      <Text textStyle="sm" fontWeight="medium" opacity="0.5">
        Credits: photos from Unsplash.com, icons from Icons8, graphics from
        craftwork.design.
      </Text>
      <Text my="52px" textStyle="sm" fontWeight="medium">
        Made with ✨❤️ at nFactorial in 2022.
      </Text>
    </Flex>
  );
}
