import {
  Avatar,
  Center,
  Circle,
  Flex,
  Text,
  Image,
  Box,
  Tag,
} from "@chakra-ui/react";
import { useNavigate } from "react-router-dom";

export function NewsItem({
  id,
  avatar,
  authorName,
  title,
  description,
  tag,
  duration,
  type,
  date,
  image,
}) {
  const navigate = useNavigate();
  const naviagtetoNews = () => {
    navigate(`/news/${id}`);
  };

  return (
    <Flex
      w="100%"
      justifyContent="space-between"
      pb="45px"
      borderBottom="1px solid rgba(0, 0, 0, 0.2)"
      gap="50px"
    >
      <Box>
        <Center justifyContent="flex-start" gap="4px">
          <Avatar
            w="24px"
            h="24px"
            size="24px"
            src={avatar}
            objectFit="cover"
          />
          <Text fontWeight="medium" textStyle="sm" color="black">
            {authorName}
          </Text>
          <Circle size="3px" bgColor="black" mx="8px" />
          <Text fontWeight="medium" textStyle="sm" color="black" opacity="0.5">
            {date}
          </Text>
        </Center>

        <Text
          mt="50px"
          fontSize="28px"
          fontWeight="bold"
          lineHeight="34px"
          cursor="pointer"
          onClick={naviagtetoNews}
          _hover={{
            color: "#EA6531",
          }}
        >
          {title}
        </Text>
        <Text mt="24px" textStyle="md" fontWeight="normal" maxW="693px">
          {description}
        </Text>

        <Center justifyContent="space-between" w="100%" gap="8px" mt="70px">
          <Center justifyContent="flex-start" gap="8px">
            <Tag bgColor="#081E341F" borderRadius="100px" p="6px 16px">
              {tag}
            </Tag>
            <Text
              fontWeight="medium"
              textStyle="sm"
              color="black"
              opacity="0.5"
            >
              {duration}
            </Text>
            <Circle size="3px" bgColor="black" />
            <Text
              fontWeight="medium"
              textStyle="sm"
              color="black"
              opacity="0.5"
            >
              {type}
            </Text>
          </Center>
          <Center justifyContent="flex-start" gap="14px">
            <Box w="24px" h="24px" bgColor="#E1E0E6" />
            <Box w="24px" h="24px" bgColor="#E1E0E6" />
            <Box w="24px" h="24px" bgColor="#E1E0E6" />
          </Center>
        </Center>
      </Box>
      <Image
        src={image}
        borderRadius="4px"
        w="265px"
        h="265px"
        objectFit="cover"
      />
    </Flex>
  );
}
